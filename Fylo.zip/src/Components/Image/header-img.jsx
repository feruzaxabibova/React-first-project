import "./header-img.css";

function Image() {
    return (
        <div class="container">
        <div class="site-headder__img">
            <img src="../../images/header-image.svg" alt="header image" width="720" height="534" />
        </div>
    </div>
    )
}

export default Image;